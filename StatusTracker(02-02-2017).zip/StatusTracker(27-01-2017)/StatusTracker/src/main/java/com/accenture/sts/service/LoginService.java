package com.accenture.sts.service;

import com.accenture.sts.entity.Employee;

public interface LoginService {
	
	public Employee searchResource(String emp_Id, String pass);

	public int changepwd(String empID, Employee employee);
}
