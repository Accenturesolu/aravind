package com.accenture.sts.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Upload_Ticket")
public class Upload_ticket {
	@Id
	@Column(name = "Ticket_ID")
	private String ticket_id;

	@Column(name = "Ticket_Desc")
	private String ticket_desc;

	@Column(name = "Application_Name")
	private String application_name;

	@Column(name = "Flag", nullable = false, columnDefinition = "int default 0")
	private int flag;
	
	@Column(name = "Created_by")
	private String Created_by;
	
	@Column(name = "Created_on")
	private String Created_on;

	public int getFlag() {
		return flag;
	}

	public void setFlag(int flag) {
		this.flag = flag;
	}

	public String getTicket_id() {
		return ticket_id;
	}

	public void setTicket_id(String ticket_id) {
		this.ticket_id = ticket_id;
	}

	public String getTicket_desc() {
		return ticket_desc;
	}

	public void setTicket_desc(String ticket_desc) {
		this.ticket_desc = ticket_desc;
	}

	public String getApplication_name() {
		return application_name;
	}

	public void setApplication_name(String application_name) {
		this.application_name = application_name;
	}
	
	public String getCreated_by() {
		return Created_by;
	}

	public void setCreated_by(String created_by) {
		Created_by = created_by;
	}

	public String getCreated_on() {
		return Created_on;
	}

	public void setCreated_on(String created_on) {
		Created_on = created_on;
	}

	public String toString(){
		return application_name+" "+ticket_id+" "+ticket_desc;
		
	}

}
