package com.accenture.sts.dao;

import com.accenture.sts.entity.Employee;

public interface LoginDAO {
	
	public Employee searchResource(String emp_Id, String pass);

	public int changepwd(String empID, Employee employee);
}
